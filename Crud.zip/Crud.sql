CREATE DATABASE sena;


USE sena;


CREATE TABLE aprendices(
id INT (20) UNIQUE PRIMARY KEY,
nombre_apellido VARCHAR (50) UNIQUE NOT NULL,
correo VARCHAR(50) UNIQUE NOT NULL,
edad INT UNSIGNED NOT NULL,
direccion VARCHAR(30) NOT NULL,
ciudad VARCHAR(20) NOT NULL,
estado ENUM('Activo', 'Inactivo') DEFAULT 'Inactivo',
creado TIMESTAMP DEFAULT CURRENT_TIMESTAMP
);


INSERT INTO aprendices (id, nombre_apellido, correo, edad, direccion, ciudad, estado)
VALUES ( 10001, 'Cristian Rincon', 'crisfer00055@gmail.com', 18, 'Crra 25 # 5 - 15 Sur', 'Garzon', 'Inactivo');
INSERT INTO aprendices (id, nombre_apellido, correo, edad, direccion, ciudad, estado)
VALUES  (10002, 'Camilo Cordoba', 'camilo@gmail.com', 46, 'Crra 15 # 8 - 58 Sur', 'Garzon', 'Inactivo');
INSERT INTO aprendices (id, nombre_apellido, correo, edad, direccion, ciudad, estado)
VALUES  (10003, 'Pablo Perez', 'Pablo@gmail.com', 45, 'Crra 18 # 12 - 18 Sur', 'Garzon', 'Inactivo');
INSERT INTO aprendices (id, nombre_apellido, correo, edad, direccion, ciudad, estado)
VALUES  (10004, 'Roger Avila', 'roger@gmail.com', 36 , 'Crra 56 # 12 - 16 Sur', 'Garzon', 'Inactivo');
INSERT INTO aprendices (id, nombre_apellido, correo, edad, direccion, ciudad, estado)
VALUES  (10005, 'Tobias Alto', 'tobias@gmail.com', 28 , 'Crra 12 # 46 - 21 Sur', 'Garzon', 'Inactivo');
INSERT INTO aprendices (id, nombre_apellido, correo, edad, direccion, ciudad, estado)
VALUES  (10006, 'Camilo Lopez', 'camiloo@gmail.com', 19 , 'Crra 12 # 46 - 26 Sur', 'Garzon', 'Inactivo');
INSERT INTO aprendices (id, nombre_apellido, correo, edad, direccion, ciudad, estado)
VALUES  (10007, 'Camila Argenis', 'camilamelo@gmail.com', 33 , 'Crra 12 # 5 - 118 Sur', 'Garzon', 'Inactivo');
INSERT INTO aprendices (id, nombre_apellido, correo, edad, direccion, ciudad, estado)
VALUES  (10008, 'Benito Camelo', 'benitocamelo@gmail.com', 26 , 'Crra 25 # 5 - 15 Sur', 'Garzon', 'Inactivo');
INSERT INTO aprendices (id, nombre_apellido, correo, edad, direccion, ciudad, estado)
VALUES  (10009, 'Michale Towers', 'Mchale@gmail.com',24 , 'Crra 25 # 8 - 23 Norte', 'Garzon', 'Inactivo');
INSERT INTO aprendices (id, nombre_apellido, correo, edad, direccion, ciudad, estado)
VALUES  (10010, 'Salomon Villada', 'salo@gmail.com', 22 , 'Crra 10 # 25 - 47 Sur', 'Garzon', 'Inactivo');
INSERT INTO aprendices (id, nombre_apellido, correo, edad, direccion, ciudad, estado)
VALUES  (10011, 'Yefferson Cossio', 'yfcssio@gmail.com', 20 , 'Crra 14 # 8 - 36 Este', 'Garzon', 'Inactivo');
INSERT INTO aprendices (id, nombre_apellido, correo, edad, direccion, ciudad, estado)
VALUES  (10012, 'Mauricio Liendra', 'mauro@gmail.com',41 , 'Cll 18 # 7 - 18 Sur', 'Garzon', 'Inactivo');
INSERT INTO aprendices (id, nombre_apellido, correo, edad, direccion, ciudad, estado)
VALUES  (10013, 'Lucas Molleja', 'lucasmja@hotmail.com', 18 , 'Crra 45 # 45 - 45 Sur', 'Garzon', 'Inactivo');
INSERT INTO aprendices (id, nombre_apellido, correo, edad, direccion, ciudad, estado)
VALUES  (10014, 'Falcao Garcia', 'falcon@gmail.com', 48 , 'Crra 1 # 46 - 231 Sur', 'Garzon', 'Inactivo')
INSERT INTO aprendices (id, nombre_apellido, correo, edad, direccion, ciudad, estado)
VALUES  (10016, 'Cristiano Ronaldo', 'cr7siuuu@outlook.com', 36 , 'Crra 2 # 6 - 15 Norte', 'Garzon', 'Inactivo');
INSERT INTO aprendices (id, nombre_apellido, correo, edad, direccion, ciudad, estado)
VALUES  (10017, 'Neymar Jr', 'piscinerojaja@gmail.com', 35 , 'Crra 12 # 56 - 12 Norte', 'Garzon', 'Inactivo');
